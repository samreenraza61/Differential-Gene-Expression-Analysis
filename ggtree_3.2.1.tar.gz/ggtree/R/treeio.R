has.slot <- treeio:::has.slot
getNodeNum <- treeio:::getNodeNum
getRoot <- tidytree:::rootnode
get.tree <- treeio::get.tree
drop.tip <- treeio::drop.tip
get.fields <- treeio::get.fields
is.tree <- getFromNamespace('is.tree', 'treeio')

set_branch_length <- getFromNamespace("set_branch_length", "treeio")
